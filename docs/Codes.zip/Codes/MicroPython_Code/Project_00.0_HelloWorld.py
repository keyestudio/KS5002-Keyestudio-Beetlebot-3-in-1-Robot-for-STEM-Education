
print('Hello World!\n')